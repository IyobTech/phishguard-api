// Replace this with the exact HTTPS Render URL of your deployed API.
const API_BASE_URL = "https://YOUR-RENDER-SERVICE.onrender.com";

const statusEl = document.getElementById("status");
const scoreEl = document.getElementById("score");
const predictionEl = document.getElementById("prediction");
const urlEl = document.getElementById("url");
const signalsEl = document.getElementById("signals");
const meterFill = document.getElementById("meterFill");

function setState(kind, text) {
  statusEl.className = `status ${kind}`;
  statusEl.textContent = text;
}

function renderResult(data) {
  const risk = Number(data.risk_score || 0);
  scoreEl.textContent = `${risk.toFixed(1)} / 100`;
  predictionEl.textContent = data.prediction || "Unknown";
  urlEl.textContent = data.url || "—";
  meterFill.style.width = `${Math.max(0, Math.min(100, risk))}%`;

  const phishing = Boolean(data.is_phishing);
  setState(phishing ? "bad" : "good", phishing ? "Potential phishing detected" : "Likely legitimate");

  signalsEl.textContent = "";
  for (const signal of (data.signals || [])) {
    const li = document.createElement("li");
    li.textContent = signal;
    signalsEl.appendChild(li);
  }
}

async function analyzeCurrentTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tabs?.[0]?.url;
    if (!url || /^(chrome|edge|about|chrome-extension):/i.test(url)) {
      throw new Error("This browser page cannot be analyzed by the extension.");
    }

    const response = await fetch(`${API_BASE_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "API request failed.");
    renderResult(data);
  } catch (error) {
    setState("bad", "Analysis failed");
    scoreEl.textContent = "—";
    predictionEl.textContent = error.message;
    signalsEl.innerHTML = "<li>Check the Render API URL and extension host permission.</li>";
  }
}

analyzeCurrentTab();

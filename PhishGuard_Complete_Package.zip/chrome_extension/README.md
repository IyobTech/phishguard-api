# PhishGuard Chrome Extension

This Manifest V3 extension analyzes the URL of the current browser tab by sending only the URL string to your PhishGuard Render API.

## Connect it to Render

1. Deploy the API and copy the HTTPS `onrender.com` URL.
2. In `manifest.json`, replace `https://YOUR-RENDER-SERVICE.onrender.com/*` with your exact API origin, for example `https://my-phishguard.onrender.com/*`.
3. In `popup.js`, replace `https://YOUR-RENDER-SERVICE.onrender.com` with the same exact origin.
4. Open `chrome://extensions`.
5. Enable **Developer mode**.
6. Select **Load unpacked** and choose this `chrome_extension` folder.
7. Open a normal webpage, click the PhishGuard extension, and inspect the result.

The extension intentionally uses `activeTab` so it does not need blanket access to every website. Chrome's extension model requires host permission for the remote API used by cross-origin `fetch()` calls.

## Important

Do not put model files, API credentials, or private keys into the extension. The extension should call the Render API; the model stays server-side.
